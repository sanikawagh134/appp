<?php
include "function.php";
include "global.php";
include "msk.php";
include "bin.php";
include "iban.php";
include "ch.php";
include "sch.php";
include "au.php";
include "sk.php";
include "addbug.php";
include "ip.php";
include "mch.php";
include "spp.php";
?>